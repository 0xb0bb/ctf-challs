#!/bin/sh
nc challenge.pwny.racing 40014
