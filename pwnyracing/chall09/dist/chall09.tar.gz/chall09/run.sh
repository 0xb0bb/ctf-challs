#!/bin/bash
qemu-arm ./chall09
