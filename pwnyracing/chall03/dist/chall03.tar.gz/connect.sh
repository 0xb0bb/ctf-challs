#!/bin/sh
nc challenge.pwny.racing 40003
